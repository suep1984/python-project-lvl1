#!/usr/bin/env python
from brain_games.scripts.brain_games_engine import gcd

print('Find the greatest common divisor of given numbers')


def main():
    gcd()


if __name__ == '__main__':
    main()

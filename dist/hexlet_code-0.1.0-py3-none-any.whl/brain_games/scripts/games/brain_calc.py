#!/usr/bin/env python
from brain_games.scripts.brain_games_engine import calc

print('What is the result of the expression?')


def main():
    calc()


if __name__ == '__main__':
    main()

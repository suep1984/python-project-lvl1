#!/usr/bin/env python
from brain_games.scripts.brain_games_engine import progression

print('What number is missing in the progression?')


def main():
    progression()


if __name__ == '__main__':
    main()

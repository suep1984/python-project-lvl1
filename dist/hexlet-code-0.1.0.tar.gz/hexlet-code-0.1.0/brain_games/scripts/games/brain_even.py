#!/usr/bin/env python
from brain_games.scripts.brain_games_engine import even

print('Answer "yes" if the number is even, otherwise answer "no".')


def main():
    even()


if __name__ == '__main__':
    main()
